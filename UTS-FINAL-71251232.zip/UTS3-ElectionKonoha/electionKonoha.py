def validasi_dan_catat_suara(nama_pemilih: str, paslon_id: int, distrik: str, pemilu_data: dict, voters_set: set) -> tuple:
    nama_pemilih = nama_pemilih.strip()
    if not nama_pemilih:
        return False, "Nama pemilih tidak boleh kosong."

    if paslon_id not in pemilu_data:
        return False, "Pasangan calon tidak valid."
    if distrik not in pemilu_data[paslon_id]["suara_distrik"]:
        return False, "Distrik tidak valid."

    nama_normal = nama_pemilih.casefold()
    if any(
        isinstance(nama_terdaftar, str)
        and nama_terdaftar.strip().casefold() == nama_normal
        for nama_terdaftar in voters_set
    ):
        return False, "Nama pemilih sudah terdaftar."

    pemilu_data[paslon_id]["suara_distrik"][distrik] += 1
    voters_set.add(nama_pemilih)
    return True, "Suara berhasil dicatat."


def hitung_agregasi_dan_konversi(pemilu_data: dict) -> list:
    list_kandidat = []
    if not pemilu_data:
        return list_kandidat

    total_nasional = sum(
        sum(data_paslon["suara_distrik"].values())
        for data_paslon in pemilu_data.values()
    )

    for nomor_urut, data_paslon in pemilu_data.items():
        suara_distrik = data_paslon["suara_distrik"]
        suara_utara = suara_distrik["Distrik Utara"]
        suara_pusat = suara_distrik["Distrik Pusat"]
        suara_selatan = suara_distrik["Distrik Selatan"]
        total_suara = suara_utara + suara_pusat + suara_selatan
        persentase = (
            (total_suara / total_nasional) * 100
            if total_nasional
            else 0.0
        )
        kandidat = data_paslon["kandidat"]

        list_kandidat.append({
            "Nomor Urut": nomor_urut,
            "Nama Capres": kandidat["Ketua"],
            "Nama Cawapres": kandidat["Wakil"],
            "Distrik Utara": suara_utara,
            "Distrik Pusat": suara_pusat,
            "Distrik Selatan": suara_selatan,
            "Total Suara": total_suara,
            "Persentase": persentase,
        })

    return list_kandidat


def manual_sort(data_list: list, target_key: str) -> list:
    if not data_list:
        return []
    data_terurut = [dict(item) for item in data_list]

    for batas in range(len(data_terurut) - 1, 0, -1):
        for indeks in range(batas):
            if data_terurut[indeks][target_key] < data_terurut[indeks + 1][target_key]:
                data_terurut[indeks], data_terurut[indeks + 1] = (
                    data_terurut[indeks + 1],
                    data_terurut[indeks],
                )

    return data_terurut
