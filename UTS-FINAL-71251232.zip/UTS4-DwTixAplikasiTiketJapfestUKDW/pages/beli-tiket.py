import streamlit as st
from logout import logout
from data import user_data_by_username, participant_data_by_id, event_data

st.set_page_config(page_title="DwTix - Beli Tiket")

if not st.session_state.get("logged_in", False):
    st.switch_page("app.py")
    st.stop()
if st.session_state.get("role") not in ("Peserta", "Pengunjung"):
    st.switch_page("pages/dashboard.py")
    st.stop()

logout()
st.title("Beli Tiket")

info = event_data()["info"]
peserta = participant_data_by_id()
user = user_data_by_username()[st.session_state.uname]
user_id = st.session_state.id

st.write(f"{info['nama']}  |  Harga: Rp{info['harga_tiket']:,}  |  Kuota: {info['kuota']}")

if st.button("Beli Tiket", type="primary"):
    field_profile = ("email", "gender", "phone", "address")
    profile_lengkap = all(
        user.get(field) is not None and str(user[field]).strip()
        for field in field_profile
    )

    if not profile_lengkap:
        st.error("Lengkapi data profile terlebih dahulu.")
    elif len(peserta) >= info["kuota"]:
        st.error("Kuota tiket sudah habis.")
    else:
        nomor_terbesar = max(
            (
                int(ticket_id[2:])
                for ticket_id in peserta
                if ticket_id.startswith("ID") and ticket_id[2:].isdigit()
            ),
            default=0,
        )
        ticket_id_baru = f"ID{nomor_terbesar + 1:02d}"
        peserta[ticket_id_baru] = {
            "user_id": user_id,
            "status_bayar": "Paid",
            "status_tiket": "Belum Check-In",
        }
        st.success("Berhasil membeli tiket!")

# tampilkan sisa kuota (SUDAH JADI)
st.write(f"Sisa kuota: {info['kuota'] - len(peserta)}")

st.subheader("Tiket Saya")
tiket_saya = [
    (ticket_id, tiket)
    for ticket_id, tiket in peserta.items()
    if tiket["user_id"] == user_id
]
if not tiket_saya:
    st.info("Kamu belum punya tiket.")
else:
    for ticket_id, tiket in tiket_saya:
        st.write(
            f"{ticket_id} | {tiket['status_bayar']} | {tiket['status_tiket']}"
        )
