import streamlit as st
from pathlib import Path
from logout import logout
from data import user_data_by_username, event_data

st.set_page_config(page_title="DwTix - Event")

if not st.session_state.get("logged_in", False):
    st.switch_page("app.py")
    st.stop()

logout()
# tampilkan list (sponsor / pengisi acara / rundown), kalau can_edit muncul pilihan + tombol hapus dan form tambah (SUDAH JADI: daftar, selectbox, st.form dan input-nya)
def tampil_list(judul, key, kolom, can_edit):
    event = event_data()
    st.subheader(judul)

    if len(event[key]) == 0:
        st.info(f"Belum ada data {judul.lower()}.")

    pilihan = []
    for item in event[key]:
        teks = " — ".join(str(item[k]) for k in kolom)
        st.write(teks)
        pilihan.append(teks)

    # hapus data, buat admin dan staff
    if can_edit and len(pilihan) > 0:
        dipilih = st.selectbox(f"Pilih {judul} yang mau dihapus", pilihan)
        if st.button(f"Hapus {judul}"):
            indeks = pilihan.index(dipilih)
            event[key].pop(indeks)
            st.rerun()

    # form tambah data, buat admin dan staff
    if can_edit:
        with st.form(f"form_{key}", clear_on_submit=True):
            st.write(f"Tambah {judul}")
            data_baru = {}
            for k in kolom:
                data_baru[k] = st.text_input(k.replace("_", " ").title())
            if st.form_submit_button("Tambah"):
                if any(not nilai.strip() for nilai in data_baru.values()):
                    st.error("Semua field wajib diisi!")
                else:
                    event[key].append(data_baru)
                    st.rerun()


# untuk determine bisa ga edit ni page
def konten(can_edit):
    event = event_data()
    info = event["info"]


    # edit info utama event
    if can_edit:
        with st.expander("Edit Info Event"):
                nama = st.text_input("Nama Event", value=info["nama"])
                tanggal = st.text_input("Tanggal", value=info["tanggal"])
                lokasi = st.text_input("Lokasi", value=info["lokasi"])
                deskripsi = st.text_area("Deskripsi", value=info["deskripsi"])
                harga = st.number_input("Harga Tiket", min_value=0, step=5000, value=info["harga_tiket"])
                kuota = st.number_input("Kuota", min_value=0, step=1, value=info["kuota"])
                if st.button("Simpan", type="primary"):
                    info["nama"] = nama
                    info["tanggal"] = tanggal
                    info["lokasi"] = lokasi
                    info["deskripsi"] = deskripsi
                    info["harga_tiket"] = int(harga)
                    info["kuota"] = int(kuota)
                    st.rerun()
    else :
        st.title(info["nama"])
        st.write(f"{info['tanggal']}  |  {info['lokasi']}")
        st.write(info["deskripsi"])
        st.write(f"🎟️ Harga tiket: Rp{info['harga_tiket']:,}  |  Kuota: {info['kuota']} orang")

    st.divider()
    tampil_list("Sponsor", "sponsor", ["nama", "tier"], can_edit)
    st.divider()
    tampil_list("Pengisi Acara", "pengisi_acara", ["nama", "jenis"], can_edit)
    st.divider()
    tampil_list("Rundown", "rundown", ["jam", "acara"], can_edit)


role = st.session_state.role
img_path = Path(__file__).parent.parent / "japfest.png"
st.image(img_path)

can_edit = role in ("Admin", "Staff")
konten(can_edit)
