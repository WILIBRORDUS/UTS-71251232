import streamlit as st
from data import user_data_by_username
from logout import logout

if not st.session_state.get("logged_in", False):
    st.switch_page("app.py")
    st.stop()

logout()
st.header("Profile", text_alignment="center", divider="green")

with st.expander("Edit Profile"):
    uname = st.text_input("Username", value=st.session_state.uname, disabled=True )
    email = st.text_input("Email", value=user_data_by_username()[st.session_state.uname]["email"])
    pword = st.text_input("Password", type="password", value=user_data_by_username()[st.session_state.uname]["password"])
    gender = st.text_input("Gender", value=user_data_by_username()[st.session_state.uname]["gender"])
    phone = st.text_input("Phone", value=user_data_by_username()[st.session_state.uname]["phone"])
    address = st.text_input("Address", value=user_data_by_username()[st.session_state.uname]["address"])
    if st.button("Ubah Data", type="primary"):
        user = user_data_by_username()[st.session_state.uname]
        data_baru = {
            "email": email,
            "password": pword,
            "gender": gender,
            "phone": phone,
            "address": address,
        }
        field_berubah = [
            key
            for key, nilai_baru in data_baru.items()
            if (user[key] if user[key] is not None else "") != nilai_baru
        ]

        if not field_berubah:
            st.info("Belum ada perubahan loh ya")
        else:
            for key in field_berubah:
                user[key] = data_baru[key]
            st.success(f"Gokilss, anda mengubah: {', '.join(field_berubah)}")
