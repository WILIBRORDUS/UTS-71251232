import streamlit as st
from data import user_data_by_username

def main():
    # set tab title -> https://docs.streamlit.io/develop/concepts/multipage-apps/page-and-navigation silahkan >
    st.set_page_config(page_title="DwTix - Login")

    st.session_state.setdefault("logged_in", False)
    st.session_state.setdefault("uname", None)
    st.session_state.setdefault("id", None)
    st.session_state.setdefault("role", None)
    if st.session_state.logged_in:
        st.switch_page("pages/event.py")

    # kalau misal ada error itu gara gara versi streamlit minimal 1.52.0 ya
    # silahkan up pakai pip install --upgrade streamlit
    # page header (SUDAH JADI)
    st.header("Selamat datang kembali", text_alignment="center", divider="green")
    st.write("*Silahkan masuk menggunakan akun DwTix anda*")

    user_by_name = user_data_by_username()
    # form (SUDAH JADI)
    uname = st.text_input(label="Username", required=True)
    pword = st.text_input(label="Password", type="password", required=True)

    # submit
    if st.button(label="Login", type="primary"):
        user = user_by_name.get(uname)
        if user is None or user["password"] != pword:
            st.error("Login gagal! Silahkan coba kembali.")
        else:
            st.session_state.logged_in = True
            st.session_state.uname = uname
            st.session_state.id = user["id"]
            st.session_state.role = user["role"]
            if user["role"] in ("Admin", "Staff"):
                st.switch_page("pages/dashboard.py")
            else:
                st.switch_page("pages/event.py")

if __name__ == '__main__':
    main()
